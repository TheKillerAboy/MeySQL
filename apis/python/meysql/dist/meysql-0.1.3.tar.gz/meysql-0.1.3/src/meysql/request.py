import json
import os
import socket

def request(req):
    HOST = os.environ.get("MEYSQL_HOST",'localhost')
    PORT = os.environ.get("MEYSQL_PORT")

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((HOST, PORT))
        s.sendall(json.dumps(req).encode())
        return json.loads(s.recv(32767).decode())